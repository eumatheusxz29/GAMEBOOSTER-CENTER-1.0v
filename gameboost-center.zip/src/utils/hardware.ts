import { HardwareStats } from '../types/gameboost';

// Detect WebGL GPU information
export function getGpuInfo(): string {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (!gl) return 'Acelerador WebGL padrão';

    const debugInfo = (gl as WebGLRenderingContext).getExtension('WEBGL_debug_renderer_info');
    if (debugInfo) {
      const renderer = (gl as WebGLRenderingContext).getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
      if (renderer) {
        // Clean up common prefixes like "ANGLE (" or vendor tags for mobile
        return String(renderer).replace(/^ANGLE \((.*)\)$/, '$1');
      }
    }
    return (gl as WebGLRenderingContext).getParameter((gl as WebGLRenderingContext).RENDERER) || 'GPU Padrão';
  } catch {
    return 'Renderizador gráfico compatível';
  }
}

// Measure screen refresh rate via requestAnimationFrame
export function measureRefreshRate(): Promise<number> {
  return new Promise((resolve) => {
    let frameCount = 0;
    let startTime = 0;

    function step(timestamp: number) {
      if (!startTime) startTime = timestamp;
      frameCount++;

      if (timestamp - startTime >= 500) {
        const elapsedSec = (timestamp - startTime) / 1000;
        const rawHz = Math.round(frameCount / elapsedSec);
        // Normalize to common mobile refresh standards
        if (rawHz >= 110) resolve(120);
        else if (rawHz >= 80) resolve(90);
        else if (rawHz >= 50) resolve(60);
        else resolve(Math.max(30, rawHz));
      } else {
        requestAnimationFrame(step);
      }
    }

    requestAnimationFrame(step);
  });
}

// Gather all hardware stats
export async function getHardwareStats(): Promise<HardwareStats> {
  // RAM
  const ramGB = (navigator as unknown as { deviceMemory?: number }).deviceMemory ?? null;
  // CPU cores
  const cpuCores = navigator.hardwareConcurrency || 4;

  // Screen
  const width = window.screen.width;
  const height = window.screen.height;
  const devicePixelRatio = Math.round((window.devicePixelRatio || 1) * 10) / 10;
  const screenResolution = `${width} × ${height} (${devicePixelRatio}x)`;

  // Battery API (safe fallback)
  let batteryLevel: number | null = null;
  let isCharging: boolean | null = null;

  try {
    if ('getBattery' in navigator) {
      const battery = await (navigator as unknown as { getBattery: () => Promise<{ level: number; charging: boolean }> }).getBattery();
      batteryLevel = Math.round(battery.level * 100);
      isCharging = battery.charging;
    }
  } catch {
    // Battery API not supported or permissions restricted
  }

  // Network Information API
  let connectionType = navigator.onLine ? 'Conectado' : 'Offline';
  let downlinkMbps: number | null = null;
  let rttMs: number | null = null;

  const connection = (navigator as unknown as { connection?: { effectiveType?: string; downlink?: number; rtt?: number } }).connection;
  if (connection) {
    if (connection.effectiveType) {
      connectionType = connection.effectiveType.toUpperCase();
    }
    if (typeof connection.downlink === 'number') {
      downlinkMbps = connection.downlink;
    }
    if (typeof connection.rtt === 'number') {
      rttMs = connection.rtt;
    }
  }

  // Storage estimation
  let storageUsedMB: number | null = null;
  let storageQuotaMB: number | null = null;

  try {
    if (navigator.storage && navigator.storage.estimate) {
      const estimate = await navigator.storage.estimate();
      if (estimate.usage !== undefined) {
        storageUsedMB = Math.round(estimate.usage / (1024 * 1024));
      }
      if (estimate.quota !== undefined) {
        storageQuotaMB = Math.round(estimate.quota / (1024 * 1024));
      }
    }
  } catch {
    // ignore
  }

  // Browser heap (Chrome only)
  let browserHeapMB: number | null = null;
  if ((performance as unknown as { memory?: { usedJSHeapSize: number } }).memory) {
    const mem = (performance as unknown as { memory: { usedJSHeapSize: number } }).memory;
    browserHeapMB = Math.round(mem.usedJSHeapSize / (1024 * 1024));
  }

  const gpuRenderer = getGpuInfo();
  const screenRefreshRate = await measureRefreshRate();

  return {
    ramGB,
    cpuCores,
    screenRefreshRate,
    screenResolution,
    devicePixelRatio,
    batteryLevel,
    isCharging,
    connectionType,
    downlinkMbps,
    rttMs,
    gpuRenderer,
    storageUsedMB,
    storageQuotaMB,
    browserHeapMB,
  };
}

// Calculate realistic 0-100 gaming score based on available hardware metrics
export function calculatePerformanceScore(stats: HardwareStats, currentFps: number): {
  score: number;
  label: string;
  colorClass: string;
  breakdown: { item: string; points: number; max: number; note: string }[];
} {
  let totalScore = 0;
  const breakdown: { item: string; points: number; max: number; note: string }[] = [];

  // 1. CPU cores (max 25 pts)
  let cpuPoints = 15;
  if (stats.cpuCores >= 8) cpuPoints = 25;
  else if (stats.cpuCores >= 6) cpuPoints = 20;
  else if (stats.cpuCores >= 4) cpuPoints = 15;
  else cpuPoints = 8;
  totalScore += cpuPoints;
  breakdown.push({
    item: 'Processador (CPU)',
    points: cpuPoints,
    max: 25,
    note: `${stats.cpuCores} núcleos detectados`,
  });

  // 2. RAM (max 25 pts)
  let ramPoints = 18; // baseline fallback if API hidden
  if (stats.ramGB !== null) {
    if (stats.ramGB >= 8) ramPoints = 25;
    else if (stats.ramGB >= 6) ramPoints = 21;
    else if (stats.ramGB >= 4) ramPoints = 16;
    else ramPoints = 10;
  }
  totalScore += ramPoints;
  breakdown.push({
    item: 'Memória RAM',
    points: ramPoints,
    max: 25,
    note: stats.ramGB ? `~${stats.ramGB} GB RAM física` : 'Restrito pelo navegador (estimado)',
  });

  // 3. FPS / Taxa de atualização (max 25 pts)
  let fpsPoints = 15;
  if (currentFps >= 58) fpsPoints = 25;
  else if (currentFps >= 45) fpsPoints = 20;
  else if (currentFps >= 30) fpsPoints = 14;
  else fpsPoints = 8;
  totalScore += fpsPoints;
  breakdown.push({
    item: 'Fluidez de Tela (FPS)',
    points: fpsPoints,
    max: 25,
    note: `${Math.round(currentFps)} FPS medido (${stats.screenRefreshRate}Hz)`,
  });

  // 4. Bateria & Térmico (max 15 pts)
  let batPoints = 12;
  if (stats.batteryLevel !== null) {
    if (stats.isCharging) batPoints = 15;
    else if (stats.batteryLevel >= 50) batPoints = 14;
    else if (stats.batteryLevel >= 25) batPoints = 10;
    else batPoints = 5; // <20% Android triggers battery saver throttling
  }
  totalScore += batPoints;
  breakdown.push({
    item: 'Alimentação & Bateria',
    points: batPoints,
    max: 15,
    note: stats.batteryLevel !== null ? `${stats.batteryLevel}% ${stats.isCharging ? '(Carregando)' : ''}` : 'Monitoramento de energia OK',
  });

  // 5. Conexão & Ping (max 10 pts)
  let netPoints = 8;
  if (stats.connectionType === 'Offline') {
    netPoints = 0;
  } else if (stats.rttMs !== null) {
    if (stats.rttMs < 60) netPoints = 10;
    else if (stats.rttMs < 120) netPoints = 7;
    else netPoints = 4;
  } else if (stats.connectionType === '4G' || stats.connectionType === 'WIFI') {
    netPoints = 9;
  }
  totalScore += netPoints;
  breakdown.push({
    item: 'Estabilidade de Rede',
    points: netPoints,
    max: 10,
    note: stats.rttMs ? `Ping ~${stats.rttMs}ms (${stats.connectionType})` : `${stats.connectionType}`,
  });

  // Clamp 0-100
  const finalScore = Math.min(100, Math.max(0, totalScore));

  let label = 'Intermediário';
  let colorClass = 'text-amber-400';
  if (finalScore >= 85) {
    label = 'Alta Performance';
    colorClass = 'text-emerald-400';
  } else if (finalScore >= 70) {
    label = 'Bom para Jogos';
    colorClass = 'text-cyan-400';
  } else if (finalScore < 50) {
    label = 'Ajustes Necessários';
    colorClass = 'text-rose-400';
  }

  return {
    score: finalScore,
    label,
    colorClass,
    breakdown,
  };
}
