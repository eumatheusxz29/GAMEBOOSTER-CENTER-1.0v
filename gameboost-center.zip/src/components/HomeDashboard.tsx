import React, { useState } from 'react';
import { 
  Zap, Cpu, HardDrive, Battery, BatteryCharging, Wifi, 
  Activity, ShieldAlert, Sparkles, ChevronRight, CheckCircle2,
  RefreshCw, Smartphone
} from 'lucide-react';
import { HardwareStats } from '../types/gameboost';
import { calculatePerformanceScore } from '../utils/hardware';
import { sound } from '../utils/sound';
import confetti from 'canvas-confetti';

interface HomeDashboardProps {
  stats: HardwareStats | null;
  currentFps: number;
  gameModeActive: boolean;
  onToggleGameMode: () => void;
  onGoToBoost: () => void;
  onGoToMonitor: () => void;
  onRefreshHardware: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  stats,
  currentFps,
  gameModeActive,
  onToggleGameMode,
  onGoToBoost,
  onGoToMonitor,
  onRefreshHardware,
}) => {
  const [showBreakdown, setShowBreakdown] = useState(false);

  // Compute realistic performance score
  const fallbackStats: HardwareStats = stats || {
    ramGB: null,
    cpuCores: 8,
    screenRefreshRate: 60,
    screenResolution: '1080 x 2400',
    devicePixelRatio: 2,
    batteryLevel: 80,
    isCharging: false,
    connectionType: '4G',
    downlinkMbps: 15,
    rttMs: 45,
    gpuRenderer: 'Mali-G78 / Adreno 650',
    storageUsedMB: null,
    storageQuotaMB: null,
    browserHeapMB: null,
  };

  const performance = calculatePerformanceScore(fallbackStats, currentFps);

  // Circular gauge calculations
  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  const progressOffset = circumference - (performance.score / 100) * circumference;

  const handleActivateGameMode = () => {
    sound.playModeActivate();
    if (!gameModeActive) {
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.65 },
          colors: ['#00f5d4', '#10b981', '#a855f7'],
        });
      } catch {
        // ignore
      }
    }
    onToggleGameMode();
  };

  return (
    <div className="space-y-5 pb-6">
      {/* Top Banner / Status Alert */}
      <div className={`p-4 rounded-2xl border transition-all duration-300 ${
        gameModeActive
          ? 'bg-gradient-to-r from-emerald-950/60 via-slate-900 to-cyan-950/60 border-emerald-500/40 neon-glow-emerald'
          : 'bg-slate-900/60 border-slate-800/80'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              gameModeActive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'
            }`}>
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                Status do Sistema
                {gameModeActive ? (
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                    Otimizado
                  </span>
                ) : (
                  <span className="text-[10px] bg-cyan-500/20 text-cyan-400 px-2 py-0.5 rounded-full border border-cyan-500/30">
                    Modo Padrão
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                {gameModeActive
                  ? 'Foco total em estabilidade e taxa de quadros.'
                  : 'Pronto para calibrar antes da próxima partida.'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onRefreshHardware();
            }}
            title="Atualizar sensores"
            className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded-lg transition"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Big Circular Score Gauge */}
      <div className="relative p-6 rounded-3xl bg-gradient-to-b from-[#0e1626] to-[#070b14] border border-slate-800 shadow-xl overflow-hidden text-center">
        {/* Ambient background glow */}
        <div className={`absolute -top-16 left-1/2 -translate-x-1/2 w-48 h-48 rounded-full blur-3xl pointer-events-none transition-all duration-700 ${
          performance.score >= 80 ? 'bg-emerald-500/20' : performance.score >= 60 ? 'bg-cyan-500/20' : 'bg-amber-500/20'
        }`} />

        <div className="relative z-10 flex flex-col items-center">
          <span className="text-xs font-semibold tracking-wider uppercase text-slate-400 mb-2">
            Pontuação de Desempenho
          </span>

          {/* SVG Circular Meter */}
          <div className="relative w-48 h-48 flex items-center justify-center my-1">
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 200 200">
              {/* Background ring */}
              <circle
                cx="100"
                cy="100"
                r={radius}
                className="stroke-slate-800/80"
                strokeWidth="14"
                fill="none"
              />
              {/* Active progress ring */}
              <circle
                cx="100"
                cy="100"
                r={radius}
                stroke={performance.score >= 80 ? '#10b981' : performance.score >= 60 ? '#00f5d4' : '#f59e0b'}
                strokeWidth="14"
                strokeDasharray={circumference}
                strokeDashoffset={progressOffset}
                strokeLinecap="round"
                fill="none"
                className="transition-all duration-1000 ease-out"
                style={{
                  filter: performance.score >= 80 
                    ? 'drop-shadow(0 0 8px rgba(16, 185, 129, 0.6))' 
                    : 'drop-shadow(0 0 8px rgba(0, 245, 212, 0.6))'
                }}
              />
            </svg>

            {/* Inner score label */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl font-gamer font-bold text-white tracking-tighter">
                {performance.score}
              </span>
              <span className="text-[11px] font-semibold tracking-wider text-slate-400 uppercase mt-0.5">
                de 100
              </span>
            </div>
          </div>

          {/* Rating tag */}
          <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/80">
            <span className={`w-2 h-2 rounded-full ${
              performance.score >= 80 ? 'bg-emerald-400' : performance.score >= 60 ? 'bg-cyan-400' : 'bg-amber-400'
            }`} />
            <span className={`text-xs font-bold ${performance.colorClass}`}>
              {performance.label}
            </span>
          </div>

          <p className="text-xs text-slate-400 mt-2 max-w-xs">
            Calculado com base na memória, núcleos de CPU, fluidez de tela (FPS), bateria e latência da rede.
          </p>

          {/* Breakdown Toggle Button */}
          <button
            onClick={() => {
              sound.playClick();
              setShowBreakdown(!showBreakdown);
            }}
            className="mt-3 text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1 transition"
          >
            <span>{showBreakdown ? 'Ocultar detalhes do cálculo' : 'Ver como a pontuação foi calculada'}</span>
            <ChevronRight className={`w-3.5 h-3.5 transition-transform ${showBreakdown ? 'rotate-90' : ''}`} />
          </button>
        </div>

        {/* Detailed Breakdown */}
        {showBreakdown && (
          <div className="mt-4 pt-4 border-t border-slate-800 text-left space-y-2.5">
            {performance.breakdown.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <div>
                  <div className="font-semibold text-slate-200">{item.item}</div>
                  <div className="text-[11px] text-slate-400">{item.note}</div>
                </div>
                <div className="text-right">
                  <span className="font-bold text-cyan-400 font-gamer">{item.points}</span>
                  <span className="text-slate-500">/{item.max} pts</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Main Big CTA Button: ATIVAR MODO JOGO */}
      <div>
        <button
          onClick={handleActivateGameMode}
          className={`w-full py-4 px-6 rounded-2xl font-gamer text-base font-bold tracking-wider transition-all duration-300 flex items-center justify-center gap-3 shadow-xl ${
            gameModeActive
              ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-500 text-black neon-glow-emerald scale-[1.01]'
              : 'bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 text-white hover:opacity-95 neon-glow-cyan active:scale-95'
          }`}
        >
          <Zap className={`w-5 h-5 ${gameModeActive ? 'fill-black' : 'fill-white animate-bounce'}`} />
          <span>{gameModeActive ? 'MODO JOGO ATIVADO' : 'ATIVAR MODO JOGO'}</span>
        </button>
        <p className="text-[11px] text-center text-slate-500 mt-1.5">
          {gameModeActive
            ? 'Toque novamente para retornar ao modo convencional.'
            : 'Otimiza o cache do app, trava taxas de quadros e guia ações do sistema.'}
        </p>
      </div>

      {/* Hardware Telemetry Cards Grid */}
      <div className="grid grid-cols-2 gap-3">
        {/* RAM Card */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition">
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-xs font-medium">RAM Estimada</span>
            <HardDrive className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-lg font-bold text-white font-gamer">
            {fallbackStats.ramGB ? `${fallbackStats.ramGB} GB` : '4+ GB'}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5 truncate">
            {fallbackStats.ramGB ? 'Detectada pelo navegador' : 'Estimativa de sistema'}
          </div>
        </div>

        {/* CPU Cores */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition">
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-xs font-medium">Núcleos CPU</span>
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-lg font-bold text-white font-gamer">
            {fallbackStats.cpuCores} núcleos
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            hardwareConcurrency
          </div>
        </div>

        {/* Battery Card */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition">
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-xs font-medium">Bateria</span>
            {fallbackStats.isCharging ? (
              <BatteryCharging className="w-4 h-4 text-emerald-400 animate-pulse" />
            ) : (
              <Battery className="w-4 h-4 text-amber-400" />
            )}
          </div>
          <div className="text-lg font-bold text-white font-gamer">
            {fallbackStats.batteryLevel !== null ? `${fallbackStats.batteryLevel}%` : 'Disponível'}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5 truncate">
            {fallbackStats.isCharging ? 'Conectado ao carregador' : 'Em uso regular'}
          </div>
        </div>

        {/* Connection Card */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition">
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-xs font-medium">Conexão & Ping</span>
            <Wifi className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-lg font-bold text-white font-gamer">
            {fallbackStats.rttMs ? `~${fallbackStats.rttMs} ms` : fallbackStats.connectionType}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5 truncate">
            {fallbackStats.downlinkMbps ? `${fallbackStats.downlinkMbps} Mbps (${fallbackStats.connectionType})` : 'Rede ativa'}
          </div>
        </div>
      </div>

      {/* Real-time FPS & Refresh Rate Banner */}
      <div 
        onClick={() => {
          sound.playClick();
          onGoToMonitor();
        }}
        className="cursor-pointer p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 hover:border-cyan-500/40 transition flex items-center justify-between group"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-medium">FPS em Tempo Real:</span>
              <span className="text-base font-bold text-cyan-400 font-gamer">
                {Math.round(currentFps)} FPS
              </span>
            </div>
            <div className="text-[11px] text-slate-500">
              Taxa de tela {fallbackStats.screenRefreshRate}Hz • {fallbackStats.screenResolution}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 text-xs text-cyan-400 font-medium">
          <span>Monitor</span>
          <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition" />
        </div>
      </div>

      {/* Quick 1-Touch Boost Banner CTA */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-950/40 via-slate-900 to-slate-900 border border-purple-500/30 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-purple-400 font-semibold text-xs">
            <Zap className="w-4 h-4" />
            <span>Otimização em 1 Toque</span>
          </div>
          <p className="text-xs text-slate-300 mt-0.5 font-medium">
            Limpar cache e executar calibração
          </p>
          <p className="text-[11px] text-slate-400">
            Libere recursos e verifique os passos guiados
          </p>
        </div>

        <button
          onClick={() => {
            sound.playClick();
            onGoToBoost();
          }}
          className="py-2 px-3.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-medium text-xs shadow-md transition"
        >
          Otimizar
        </button>
      </div>
    </div>
  );
};
