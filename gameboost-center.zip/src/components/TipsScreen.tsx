import React, { useState } from 'react';
import { 
  Lightbulb, Search, ChevronDown, Cpu, Battery, 
  Wifi, HardDrive, Thermometer, Sliders, CheckCircle2,
  ExternalLink, Sparkles
} from 'lucide-react';
import { TIPS_DATA, TipItem } from '../data/tipsData';
import { sound } from '../utils/sound';

export const TipsScreen: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedTipIds, setExpandedTipIds] = useState<Record<string, boolean>>({
    'sys-bg-apps': true, // first one expanded by default
  });

  const categories: { label: string; icon: React.FC<{ className?: string }> }[] = [
    { label: 'Todos', icon: Sparkles },
    { label: 'Sistema', icon: Cpu },
    { label: 'Bateria', icon: Battery },
    { label: 'Rede', icon: Wifi },
    { label: 'Armazenamento', icon: HardDrive },
    { label: 'Temperatura', icon: Thermometer },
    { label: 'Gráficos', icon: Sliders },
  ];

  const toggleExpand = (id: string) => {
    sound.playClick();
    setExpandedTipIds(prev => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const filteredTips = TIPS_DATA.filter(tip => {
    const matchCat = selectedCategory === 'Todos' || tip.category === selectedCategory;
    const matchSearch = searchQuery.trim() === '' || 
      tip.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tip.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tip.content.some(c => c.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchCat && matchSearch;
  });

  const getCategoryColor = (cat: TipItem['category']) => {
    switch (cat) {
      case 'Sistema': return 'text-purple-400 bg-purple-500/10 border-purple-500/20';
      case 'Bateria': return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      case 'Rede': return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20';
      case 'Armazenamento': return 'text-blue-400 bg-blue-500/10 border-blue-500/20';
      case 'Temperatura': return 'text-rose-400 bg-rose-500/10 border-rose-500/20';
      case 'Gráficos': return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
    }
  };

  return (
    <div className="space-y-5 pb-6">
      {/* Header */}
      <div>
        <h2 className="text-base font-gamer font-bold text-white flex items-center gap-2">
          <span>Manual de Otimização Mobile</span>
        </h2>
        <p className="text-xs text-slate-400">
          Orientações práticas para eliminar travamentos e baixar o ping
        </p>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Pesquisar por ping, thermal throttling, memória..."
          className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
        />
      </div>

      {/* Categories Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {categories.map(cat => {
          const isSelected = selectedCategory === cat.label;
          const Icon = cat.icon;

          return (
            <button
              key={cat.label}
              onClick={() => {
                sound.playClick();
                setSelectedCategory(cat.label);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap flex items-center gap-1.5 transition-all ${
                isSelected
                  ? 'bg-cyan-500 text-black font-bold shadow-[0_0_12px_rgba(0,245,212,0.4)]'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tips Expandable Cards List */}
      <div className="space-y-3">
        {filteredTips.length === 0 ? (
          <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800">
            <Lightbulb className="w-10 h-10 text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-300">Nenhuma dica encontrada</p>
            <p className="text-xs text-slate-500 mt-1">Tente pesquisar com outros termos.</p>
          </div>
        ) : (
          filteredTips.map((tip) => {
            const isExpanded = !!expandedTipIds[tip.id];

            return (
              <div
                key={tip.id}
                className="rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700/80 transition-all overflow-hidden"
              >
                {/* Header (Always visible) */}
                <div
                  onClick={() => toggleExpand(tip.id)}
                  className="cursor-pointer p-4 flex items-start justify-between gap-3"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase tracking-wider ${getCategoryColor(tip.category)}`}>
                        {tip.category}
                      </span>
                      <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full font-medium">
                        {tip.badge}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white font-gamer leading-snug">
                      {tip.title}
                    </h3>

                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                      {tip.summary}
                    </p>
                  </div>

                  <div className={`p-1 text-slate-400 hover:text-white transition-transform ${isExpanded ? 'rotate-180' : ''}`}>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </div>

                {/* Expanded Detailed Content */}
                {isExpanded && (
                  <div className="px-4 pb-4 pt-1 border-t border-slate-800/80 text-xs space-y-3">
                    <div className="space-y-1.5 text-slate-300">
                      {tip.content.map((paragraph, pIdx) => (
                        <div key={pIdx} className="flex items-start gap-2">
                          <span className="text-cyan-400 mt-0.5">▪</span>
                          <span className="leading-relaxed">{paragraph}</span>
                        </div>
                      ))}
                    </div>

                    {/* Platform-specific steps if provided */}
                    {tip.osSteps && (
                      <div className="mt-3 space-y-2">
                        {tip.osSteps.map((os, osIdx) => (
                          <div key={osIdx} className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800">
                            <span className="font-bold text-cyan-400 text-[11px] block mb-1">
                              Passo a passo no {os.platform}:
                            </span>
                            <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px]">
                              {os.steps.map((s, sIdx) => (
                                <li key={sIdx}>{s}</li>
                              ))}
                            </ol>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
