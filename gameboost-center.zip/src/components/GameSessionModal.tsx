import React, { useState, useEffect } from 'react';
import { 
  X, Play, Pause, RotateCcw, Check, Sparkles, 
  Flame, Activity, ShieldCheck, Clock, Award
} from 'lucide-react';
import { GameProfile } from '../types/gameboost';
import { fpsTracker } from '../utils/fpsTracker';
import { sound } from '../utils/sound';
import confetti from 'canvas-confetti';

interface GameSessionModalProps {
  game: GameProfile;
  onClose: () => void;
  onSessionComplete: (durationMinutes: number) => void;
}

export const GameSessionModal: React.FC<GameSessionModalProps> = ({
  game,
  onClose,
  onSessionComplete,
}) => {
  // Step 1: Pre-game checklist execution
  const [checklistCompleted, setChecklistCompleted] = useState<Record<number, boolean>>({});
  const [isPreCheckDone, setIsPreCheckDone] = useState(false);

  // Step 2: Live game session timer
  const [sessionActive, setSessionActive] = useState(false);
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [currentFps, setCurrentFps] = useState(60);
  const [sessionFpsSamples, setSessionFpsSamples] = useState<number[]>([]);

  // FPS subscription during session
  useEffect(() => {
    const unsubscribe = fpsTracker.subscribe((fps) => {
      setCurrentFps(fps);
      if (sessionActive) {
        setSessionFpsSamples(prev => [...prev.slice(-300), fps]);
      }
    });
    return unsubscribe;
  }, [sessionActive]);

  // Timer interval
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (sessionActive) {
      interval = setInterval(() => {
        setSecondsElapsed(prev => prev + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [sessionActive]);

  const toggleChecklistItem = (idx: number) => {
    sound.playClick();
    setChecklistCompleted(prev => ({
      ...prev,
      [idx]: !prev[idx],
    }));
  };

  const handleStartSession = () => {
    sound.playModeActivate();
    setIsPreCheckDone(true);
    setSessionActive(true);
    try {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#00f5d4', '#10b981'],
      });
    } catch {
      // ignore
    }
  };

  const handleFinishSession = () => {
    sound.playComplete();
    const minutes = Math.max(1, Math.round(secondsElapsed / 60));
    onSessionComplete(minutes);
    onClose();
  };

  const formatTimer = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const allChecked = game.checklist.length > 0 && game.checklist.every((_, idx) => checklistCompleted[idx]);
  const avgSessionFps = sessionFpsSamples.length > 0
    ? Math.round(sessionFpsSamples.reduce((a, b) => a + b, 0) / sessionFpsSamples.length)
    : currentFps;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-4">
      <div className="w-full max-w-md bg-[#0a0f1d] border border-cyan-500/40 rounded-3xl p-5 shadow-2xl relative overflow-hidden neon-glow-cyan max-h-[90vh] flex flex-col">
        {/* Glow Accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-20 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <span className="text-2xl p-2 rounded-2xl bg-slate-800/80 border border-slate-700">
              {game.icon}
            </span>
            <div>
              <span className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider">
                Sessão Gamer
              </span>
              <h3 className="text-base font-gamer font-bold text-white">
                {game.title}
              </h3>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="overflow-y-auto no-scrollbar py-4 space-y-4 flex-1">
          {!isPreCheckDone ? (
            /* Phase 1: Pre-game checklist */
            <div className="space-y-3.5">
              <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
                <span className="text-xs font-semibold text-slate-300 block mb-1">
                  Perfil de Otimização Configurado:
                </span>
                <div className="flex items-center gap-2 text-xs">
                  <span className="px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-bold font-gamer">
                    Alvo: {game.targetFps} FPS
                  </span>
                  <span className="px-2 py-0.5 rounded bg-purple-500/10 border border-purple-500/30 text-purple-400 font-bold">
                    Gráficos: {game.graphicsSetting}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px]">
                    {game.category}
                  </span>
                </div>
                {game.notes && (
                  <p className="text-[11px] text-slate-400 mt-2 italic">
                    "{game.notes}"
                  </p>
                )}
              </div>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  <span>Checklist Pré-Jogo Obrigatório:</span>
                </h4>

                <div className="space-y-2">
                  {game.checklist.map((item, idx) => {
                    const checked = !!checklistCompleted[idx];
                    return (
                      <div
                        key={idx}
                        onClick={() => toggleChecklistItem(idx)}
                        className={`cursor-pointer p-3 rounded-xl border transition-all duration-200 flex items-center gap-3 ${
                          checked
                            ? 'bg-slate-900 border-emerald-500/40 text-slate-200'
                            : 'bg-slate-950/80 border-slate-800 hover:border-slate-700 text-slate-300'
                        }`}
                      >
                        <div className={`w-5 h-5 rounded-md flex items-center justify-center border ${
                          checked ? 'bg-emerald-500 border-emerald-400 text-black' : 'border-slate-700 bg-slate-900'
                        }`}>
                          {checked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                        <span className={`text-xs ${checked ? 'line-through text-slate-400' : 'text-slate-200 font-medium'}`}>
                          {item}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            /* Phase 2: Live In-Game Session HUD */
            <div className="space-y-4 text-center">
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-cyan-500/30 shadow-inner">
                <span className="text-[11px] font-bold uppercase tracking-widest text-cyan-400 flex items-center justify-center gap-1.5">
                  <Flame className="w-4 h-4 text-orange-400 animate-pulse" />
                  <span>Sessão em Andamento</span>
                </span>

                {/* Big Live Timer */}
                <div className="text-5xl font-gamer font-bold text-white tracking-widest my-2">
                  {formatTimer(secondsElapsed)}
                </div>

                <div className="flex items-center justify-center gap-4 text-xs mt-3 pt-3 border-t border-slate-800">
                  <div>
                    <span className="text-slate-400 block text-[10px]">FPS Atual</span>
                    <span className="text-base font-bold text-cyan-400 font-gamer">{Math.round(currentFps)}</span>
                  </div>
                  <div className="w-px h-6 bg-slate-800" />
                  <div>
                    <span className="text-slate-400 block text-[10px]">Média da Sessão</span>
                    <span className="text-base font-bold text-emerald-400 font-gamer">{avgSessionFps} FPS</span>
                  </div>
                  <div className="w-px h-6 bg-slate-800" />
                  <div>
                    <span className="text-slate-400 block text-[10px]">Alvo</span>
                    <span className="text-base font-bold text-purple-400 font-gamer">{game.targetFps} FPS</span>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900/50 border border-slate-800 text-left text-xs text-slate-400">
                <p className="flex items-center gap-1 text-slate-300 font-medium mb-0.5">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Dica de partida ativa:</span>
                </p>
                Mantenha a janela aberta em segundo plano ou tela dividida se desejar monitorar os quadros e tempo de partida.
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="pt-3 border-t border-slate-800">
          {!isPreCheckDone ? (
            <button
              onClick={handleStartSession}
              className="w-full py-3.5 px-4 rounded-2xl font-gamer text-sm font-bold tracking-wider bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-500 text-black hover:opacity-95 neon-glow-cyan flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4 fill-black" />
              <span>{allChecked ? 'COMEÇAR A JOGAR AGORA' : 'INICIAR PARTIDA'}</span>
            </button>
          ) : (
            <div className="flex gap-2">
              <button
                onClick={() => {
                  sound.playClick();
                  setSessionActive(!sessionActive);
                }}
                className="flex-1 py-3 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition"
              >
                {sessionActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{sessionActive ? 'Pausar' : 'Retomar'}</span>
              </button>

              <button
                onClick={handleFinishSession}
                className="flex-1 py-3 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-gamer font-bold text-xs tracking-wider flex items-center justify-center gap-1.5 transition shadow-lg"
              >
                <Award className="w-4 h-4" />
                <span>ENCERRAR SESSÃO</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
