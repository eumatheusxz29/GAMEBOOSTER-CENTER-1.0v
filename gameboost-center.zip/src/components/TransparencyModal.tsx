import React from 'react';
import { 
  X, ShieldCheck, AlertCircle, HardDrive, 
  Smartphone, Download, Check, Trash2, Zap
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { sound } from '../utils/sound';

interface TransparencyModalProps {
  onClose: () => void;
  storageUsedMB: number | null;
  storageQuotaMB: number | null;
}

export const TransparencyModal: React.FC<TransparencyModalProps> = ({
  onClose,
  storageUsedMB,
  storageQuotaMB,
}) => {
  const { isInstallable, install, isInstalled, isIOS } = usePWAInstall();

  const handleClearAppData = () => {
    sound.playClick();
    if (confirm('Deseja limpar todos os dados do GameBoost Center e restaurar os padrões?')) {
      localStorage.clear();
      sessionStorage.clear();
      window.location.reload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-[#090d18] border border-cyan-500/30 rounded-3xl p-5 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-gamer font-bold text-white">
                Transparência & Configurações
              </h3>
              <p className="text-[11px] text-slate-400">
                Como este aplicativo funciona de verdade
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto no-scrollbar py-4 space-y-4 flex-1 text-xs">
          {/* Official Required Disclaimer Notice */}
          <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-amber-300 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-amber-400 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Aviso Importante de Limitações Técnicas:</span>
            </div>
            <p className="text-[11px] leading-relaxed text-amber-200/90 pl-5 font-medium">
              "Apps web não podem controlar a RAM do sistema operacional; use as ações guiadas para melhores resultados."
            </p>
          </div>

          {/* Detailed What App Can & Cannot Do */}
          <div className="space-y-2">
            <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-300">
              O que este app FAZ e NÃO FAZ:
            </h4>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-start gap-2 text-slate-300">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Mede FPS real</strong> através da API requestAnimationFrame sem inventar taxas de quadros.</span>
              </div>
              <div className="flex items-start gap-2 text-slate-300">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Limpa o Cache Web</strong> e dados temporários do próprio aplicativo no dispositivo.</span>
              </div>
              <div className="flex items-start gap-2 text-slate-300">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Detecta núcleos reais</strong> e informações de hardware disponibilizadas pelo navegador.</span>
              </div>
              <div className="flex items-start gap-2 text-slate-400 border-t border-slate-800 pt-2">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span><strong>NÃO pode fechar outros aplicativos:</strong> apenas você pode fechar o WhatsApp/TikTok na multitarefa do Android/iOS.</span>
              </div>
              <div className="flex items-start gap-2 text-slate-400">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span><strong>NÃO inventa "liberou 2 GB de RAM":</strong> respeitamos a inteligência do usuário gamer.</span>
              </div>
            </div>
          </div>

          {/* PWA Installation Section */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
            <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-2 flex items-center justify-between">
              <span>Instalação PWA</span>
              {isInstalled && (
                <span className="text-emerald-400 text-[10px] bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                  Instalado
                </span>
              )}
            </h4>

            {isInstalled ? (
              <p className="text-slate-400 text-[11px]">
                O GameBoost Center está instalado como aplicativo na sua tela de início e funciona 100% offline.
              </p>
            ) : isInstallable ? (
              <div>
                <p className="text-slate-400 text-[11px] mb-2">
                  Instale na tela de início para abrir em tela cheia, sem barra de navegação, com acesso rápido.
                </p>
                <button
                  onClick={() => {
                    sound.playClick();
                    install();
                  }}
                  className="w-full py-2.5 px-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-gamer font-bold text-xs flex items-center justify-center gap-1.5 shadow-md"
                >
                  <Download className="w-4 h-4" />
                  <span>INSTALAR NO CELULAR</span>
                </button>
              </div>
            ) : isIOS ? (
              <div className="p-2.5 rounded-xl bg-slate-950 text-slate-300 text-[11px] space-y-1">
                <span className="font-semibold text-cyan-400 block">Como instalar no iPhone / iPad:</span>
                <p>1. Toque no botão <strong>Compartilhar</strong> (ícone com quadrado e seta) no Safari.</p>
                <p>2. Selecione <strong>Adicionar à Tela de Início</strong>.</p>
              </div>
            ) : (
              <p className="text-slate-400 text-[11px]">
                Execute pelo navegador compatível para instalar como atalho autônomo na tela de início.
              </p>
            )}
          </div>

          {/* Storage & Reset Section */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="font-semibold text-slate-200 block">Armazenamento Local</span>
              <span className="text-slate-400 text-[11px]">
                {storageUsedMB ? `${storageUsedMB} MB em uso` : 'Cache otimizado'}
              </span>
            </div>

            <button
              onClick={handleClearAppData}
              className="py-1.5 px-2.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs flex items-center gap-1 transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Redefinir Dados</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 text-center">
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs transition"
          >
            Entendido e Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
