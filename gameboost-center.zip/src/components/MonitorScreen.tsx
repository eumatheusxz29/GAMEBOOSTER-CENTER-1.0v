import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, AlertTriangle, ShieldCheck, Play, 
  Flame, Cpu, HardDrive, Smartphone, CheckCircle2, 
  RotateCcw, Info, Zap
} from 'lucide-react';
import { 
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, 
  Tooltip, ReferenceLine 
} from 'recharts';
import { HardwareStats, BenchmarkResult } from '../types/gameboost';
import { fpsTracker, FpsDataPoint } from '../utils/fpsTracker';
import { sound } from '../utils/sound';
import confetti from 'canvas-confetti';

interface MonitorScreenProps {
  stats: HardwareStats | null;
}

export const MonitorScreen: React.FC<MonitorScreenProps> = ({ stats }) => {
  const [currentFps, setCurrentFps] = useState<number>(60);
  const [frametime, setFrametime] = useState<number>(16.6);
  const [onePercentLow, setOnePercentLow] = useState<number>(60);
  const [jitter, setJitter] = useState<number>(0.5);
  const [history, setHistory] = useState<FpsDataPoint[]>([]);

  // Alert for frame drops
  const [dropAlert, setDropAlert] = useState<string | null>(null);

  // 10-Second Stress Test State
  const [isBenchmarking, setIsBenchmarking] = useState(false);
  const [benchmarkSecondsLeft, setBenchmarkSecondsLeft] = useState(10);
  const [benchmarkResult, setBenchmarkResult] = useState<BenchmarkResult | null>(() => {
    try {
      const saved = localStorage.getItem('gameboost_last_benchmark');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const stressCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Subscribe to live FPS tracker
  useEffect(() => {
    const unsubscribe = fpsTracker.subscribe((fps, ft, hist) => {
      setCurrentFps(fps);
      setFrametime(ft);
      setHistory(hist);
      const telemetry = fpsTracker.getStats();
      setOnePercentLow(telemetry.onePercentLow);
      setJitter(telemetry.jitter);

      // Trigger frame drop alert if FPS falls below 45 while baseline is 60+
      if (fps < 45) {
        setDropAlert(`Queda de quadros detectada: ${fps} FPS (frametime subiu para ${ft}ms)`);
      } else {
        setDropAlert(null);
      }
    });
    return unsubscribe;
  }, []);

  // Run 10-second real stress benchmark
  const runStressTest = () => {
    if (isBenchmarking) return;
    setIsBenchmarking(true);
    setBenchmarkSecondsLeft(10);
    sound.playModeActivate();

    const collectedFps: number[] = [];
    const collectedFrameTimes: number[] = [];
    const startTime = performance.now();
    let animId: number;

    const canvas = stressCanvasRef.current;
    const ctx = canvas ? canvas.getContext('2d') : null;

    // Create 1200 heavy dynamic particles for the benchmark
    const particles = Array.from({ length: 1200 }, () => ({
      x: Math.random() * 300,
      y: Math.random() * 150,
      vx: (Math.random() - 0.5) * 4,
      vy: (Math.random() - 0.5) * 4,
      color: `hsl(${Math.random() * 360}, 100%, 60%)`,
    }));

    let lastTick = performance.now();
    let frameInSecond = 0;
    let secondStart = performance.now();

    function benchmarkLoop(now: number) {
      const elapsedTotal = (now - startTime) / 1000;
      const remaining = Math.max(0, Math.ceil(10 - elapsedTotal));
      setBenchmarkSecondsLeft(remaining);

      // Compute frame delta
      const delta = now - lastTick;
      lastTick = now;
      collectedFrameTimes.push(delta);

      frameInSecond++;
      if (now - secondStart >= 1000) {
        const secFps = Math.round((frameInSecond * 1000) / (now - secondStart));
        collectedFps.push(secFps);
        frameInSecond = 0;
        secondStart = now;
      }

      // Render particle stress load on hidden canvas
      if (ctx && canvas) {
        ctx.fillStyle = 'rgba(7, 11, 20, 0.2)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        for (let i = 0; i < particles.length; i++) {
          const p = particles[i];
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
          if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      if (elapsedTotal < 10) {
        animId = requestAnimationFrame(benchmarkLoop);
      } else {
        // Complete benchmark!
        cancelAnimationFrame(animId);
        finishBenchmark(collectedFps, collectedFrameTimes);
      }
    }

    animId = requestAnimationFrame(benchmarkLoop);
  };

  const finishBenchmark = (fpsList: number[], frameTimes: number[]) => {
    setIsBenchmarking(false);
    sound.playComplete();

    const validFps = fpsList.length > 0 ? fpsList : [currentFps];
    const avg = Math.round(validFps.reduce((a, b) => a + b, 0) / validFps.length);
    const min = Math.min(...validFps);
    const max = Math.max(...validFps);

    // Calculate 1% low from frametimes
    const sortedFT = [...frameTimes].sort((a, b) => b - a);
    const worstFT = sortedFT[Math.floor(sortedFT.length * 0.01)] || 16.6;
    const calcOnePercent = Math.max(1, Math.round(1000 / worstFT));

    // Jitter
    const avgFT = frameTimes.reduce((a, b) => a + b, 0) / (frameTimes.length || 1);
    const jitterVal = Math.round((frameTimes.map(f => Math.abs(f - avgFT)).reduce((a, b) => a + b, 0) / (frameTimes.length || 1)) * 10) / 10;

    let rating: BenchmarkResult['rating'] = 'Regular';
    let score = Math.min(100, Math.round((avg / 60) * 85 + (calcOnePercent / 60) * 15));

    if (avg >= 58 && calcOnePercent >= 50) {
      rating = 'Excelente';
    } else if (avg >= 50 && calcOnePercent >= 40) {
      rating = 'Bom';
    } else if (avg >= 35) {
      rating = 'Regular';
    } else {
      rating = 'Ruim';
    }

    const result: BenchmarkResult = {
      avgFps: avg,
      minFps: min,
      maxFps: max,
      onePercentLow: calcOnePercent,
      jitterMs: jitterVal,
      score,
      rating,
      testedAt: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    };

    setBenchmarkResult(result);
    localStorage.setItem('gameboost_last_benchmark', JSON.stringify(result));

    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#00f5d4', '#10b981'],
      });
    } catch {
      // ignore
    }
  };

  const getRatingBadge = (rating: BenchmarkResult['rating']) => {
    switch (rating) {
      case 'Excelente':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
      case 'Bom':
        return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/40';
      case 'Regular':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/40';
      case 'Ruim':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/40';
    }
  };

  return (
    <div className="space-y-5 pb-6">
      {/* Real-time FPS Header Hero Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-b from-[#0f172a] via-[#090e1a] to-[#070b14] border border-slate-800 shadow-xl relative overflow-hidden">
        {/* Glow */}
        <div className={`absolute top-0 right-0 w-44 h-44 rounded-full blur-3xl pointer-events-none ${
          currentFps >= 55 ? 'bg-emerald-500/10' : currentFps >= 40 ? 'bg-cyan-500/10' : 'bg-rose-500/10'
        }`} />

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5" />
              <span>Taxa de Quadros em Tempo Real</span>
            </span>
            <span className="text-[10px] font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
              requestAnimationFrame
            </span>
          </div>

          {/* Big FPS Counter */}
          <div className="flex items-baseline gap-3 my-1">
            <span className={`text-6xl font-gamer font-bold tracking-tight ${
              currentFps >= 55 ? 'text-emerald-400' : currentFps >= 40 ? 'text-cyan-400' : 'text-rose-400'
            }`}>
              {Math.round(currentFps)}
            </span>
            <span className="text-sm font-gamer font-semibold text-slate-400 tracking-wider">
              FPS
            </span>
          </div>

          {/* Sub-metrics: Frametime, Jitter, 1% Low */}
          <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800/80 text-center">
            <div className="p-2 rounded-xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Tempo de Quadro</span>
              <span className="text-sm font-bold text-white font-gamer">{frametime} ms</span>
            </div>
            <div className="p-2 rounded-xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Jitter (Oscilação)</span>
              <span className="text-sm font-bold text-cyan-400 font-gamer">±{jitter} ms</span>
            </div>
            <div className="p-2 rounded-xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">1% Low (Engasgos)</span>
              <span className="text-sm font-bold text-purple-400 font-gamer">{onePercentLow} FPS</span>
            </div>
          </div>
        </div>
      </div>

      {/* Frame Drop Alert Banner */}
      {dropAlert && (
        <div className="p-3 rounded-2xl bg-rose-950/60 border border-rose-500/40 flex items-center gap-3 text-rose-300 text-xs animate-pulse">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
          <span>{dropAlert}</span>
        </div>
      )}

      {/* 60 Seconds FPS Graph (Recharts) */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 font-gamer">
              Histórico dos Últimos 60 Segundos
            </h3>
            <p className="text-[11px] text-slate-400">
              Fluidez contínua da renderização na tela
            </p>
          </div>
          <div className="flex items-center gap-2 text-[10px] text-slate-400">
            <span className="inline-block w-2.5 h-0.5 bg-cyan-400 rounded" /> FPS Real
            <span className="inline-block w-2.5 h-0.5 bg-emerald-500 border-dashed rounded" /> Meta 60 FPS
          </div>
        </div>

        <div className="h-44 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={history} margin={{ top: 10, right: 0, left: -25, bottom: 0 }}>
              <defs>
                <linearGradient id="fpsColor" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00f5d4" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#00f5d4" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="time" 
                stroke="#475569" 
                tick={{ fontSize: 10, fill: '#64748b' }} 
                interval={14}
              />
              <YAxis 
                domain={[0, Math.max(75, ...history.map(d => d.fps || 60))]} 
                stroke="#475569" 
                tick={{ fontSize: 10, fill: '#64748b' }} 
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#070b14',
                  borderColor: '#1e293b',
                  borderRadius: '0.75rem',
                  fontSize: '11px',
                  color: '#fff',
                }}
                formatter={(val: any) => [`${val ?? 0} FPS`, 'Taxa de Quadros']}
                labelFormatter={(lbl: any) => `Segundo: ${String(lbl)}`}
              />
              <ReferenceLine y={60} stroke="#10b981" strokeDasharray="3 3" />
              <Area 
                type="monotone" 
                dataKey="fps" 
                stroke="#00f5d4" 
                strokeWidth={2}
                fillOpacity={1} 
                fill="url(#fpsColor)" 
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 10-Second Stress Test Section */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-900 border border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-white font-gamer">
                Teste de Estresse de 10s
              </h3>
              <p className="text-[11px] text-slate-400">
                Avalia a estabilidade da GPU sob carga pesada
              </p>
            </div>
          </div>

          <button
            onClick={runStressTest}
            disabled={isBenchmarking}
            className={`py-2 px-3.5 rounded-xl font-gamer text-xs font-bold tracking-wider transition shadow-md flex items-center gap-1.5 ${
              isBenchmarking
                ? 'bg-purple-600 text-white animate-pulse'
                : 'bg-purple-600 hover:bg-purple-500 text-white active:scale-95'
            }`}
          >
            <Play className={`w-3.5 h-3.5 ${isBenchmarking ? 'animate-spin' : 'fill-current'}`} />
            <span>{isBenchmarking ? `TESTANDO (${benchmarkSecondsLeft}s)` : 'INICIAR TESTE'}</span>
          </button>
        </div>

        {/* Hidden rendering canvas for particle stress */}
        <div className={`overflow-hidden rounded-xl bg-slate-950 transition-all ${isBenchmarking ? 'h-24 my-2 border border-purple-500/40' : 'h-0'}`}>
          <canvas ref={stressCanvasRef} width={300} height={100} className="w-full h-full object-cover opacity-80" />
        </div>

        {/* Benchmark Result Card */}
        {benchmarkResult && (
          <div className="mt-3 p-3.5 rounded-xl bg-slate-900 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] text-slate-400">Último teste às {benchmarkResult.testedAt}:</span>
              <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold border ${getRatingBadge(benchmarkResult.rating)}`}>
                Classificação: {benchmarkResult.rating}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="p-1.5 rounded-lg bg-slate-950/80">
                <span className="text-[10px] text-slate-500 block">Média</span>
                <span className="font-bold text-white font-gamer">{benchmarkResult.avgFps} FPS</span>
              </div>
              <div className="p-1.5 rounded-lg bg-slate-950/80">
                <span className="text-[10px] text-slate-500 block">Mínimo</span>
                <span className="font-bold text-rose-400 font-gamer">{benchmarkResult.minFps} FPS</span>
              </div>
              <div className="p-1.5 rounded-lg bg-slate-950/80">
                <span className="text-[10px] text-slate-500 block">1% Low</span>
                <span className="font-bold text-purple-400 font-gamer">{benchmarkResult.onePercentLow} FPS</span>
              </div>
              <div className="p-1.5 rounded-lg bg-slate-950/80">
                <span className="text-[10px] text-slate-500 block">Score</span>
                <span className="font-bold text-cyan-400 font-gamer">{benchmarkResult.score}/100</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Real Device Hardware Telemetry Sheet */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 font-gamer mb-3 flex items-center gap-1.5">
          <Smartphone className="w-4 h-4 text-cyan-400" />
          <span>Ficha Técnica do Aparelho (Métricas Reais)</span>
        </h3>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <span className="text-slate-400">Placa Gráfica (GPU WebGL):</span>
            <span className="text-slate-200 font-mono font-medium max-w-[200px] truncate text-right">
              {stats?.gpuRenderer || 'Detectando GPU...'}
            </span>
          </div>

          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <span className="text-slate-400">Resolução e Densidade:</span>
            <span className="text-slate-200 font-mono font-medium">
              {stats?.screenResolution || '1080 x 2400'}
            </span>
          </div>

          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <span className="text-slate-400">Taxa de Atualização da Tela:</span>
            <span className="text-emerald-400 font-bold font-gamer">
              {stats?.screenRefreshRate || 60} Hz
            </span>
          </div>

          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <span className="text-slate-400">Núcleos de Processamento:</span>
            <span className="text-purple-400 font-bold font-gamer">
              {stats?.cpuCores || 8} Cores
            </span>
          </div>

          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <span className="text-slate-400">Memória Física Informada:</span>
            <span className="text-cyan-400 font-bold font-gamer">
              {stats?.ramGB ? `${stats.ramGB} GB RAM` : 'Oculto por política de privacidade'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
