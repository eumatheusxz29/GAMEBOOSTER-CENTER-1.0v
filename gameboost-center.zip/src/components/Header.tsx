import React, { useState } from 'react';
import { Volume2, VolumeX, ShieldCheck, Download, Info, Zap, Flame } from 'lucide-react';
import { sound } from '../utils/sound';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HeaderProps {
  gameModeActive: boolean;
  onOpenTransparencyModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  gameModeActive,
  onOpenTransparencyModal,
}) => {
  const [soundActive, setSoundActive] = useState(sound.isEnabled());
  const { isInstallable, install, isIOS } = usePWAInstall();

  const handleToggleSound = () => {
    const nextState = sound.toggleSound();
    setSoundActive(nextState);
    if (nextState) {
      sound.playClick();
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#070b14]/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-3">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-lg shadow-lg transition-all duration-300 ${
              gameModeActive 
                ? 'bg-gradient-to-tr from-emerald-500 to-cyan-400 text-black neon-glow-emerald scale-105' 
                : 'bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 text-white'
            }`}>
              {gameModeActive ? <Flame className="w-5 h-5 animate-pulse" /> : <Zap className="w-5 h-5" />}
            </div>
            {gameModeActive && (
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-gamer font-bold tracking-wider text-base text-white">
                GAME<span className="text-cyan-400">BOOST</span>
              </span>
              <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                PRO
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              {gameModeActive ? (
                <span className="text-emerald-400 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Modo Jogo Ativo
                </span>
              ) : (
                <span className="text-slate-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                  Pronto para otimizar
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1">
          {/* PWA Install Button if available */}
          {(isInstallable || isIOS) && (
            <button
              onClick={() => {
                sound.playClick();
                install();
              }}
              title="Instalar GameBoost no celular"
              className="p-2 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 transition flex items-center gap-1 text-xs font-medium"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Instalar</span>
            </button>
          )}

          {/* Sound Toggle */}
          <button
            onClick={handleToggleSound}
            title={soundActive ? 'Desativar sons' : 'Ativar sons'}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 transition"
          >
            {soundActive ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Transparency / Honesty Disclaimer info */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenTransparencyModal();
            }}
            title="Aviso de transparência técnica"
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 transition relative"
          >
            <ShieldCheck className="w-4 h-4 text-slate-400 hover:text-cyan-400" />
            <span className="absolute 1 top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-cyan-400" />
          </button>
        </div>
      </div>
    </header>
  );
};
