import React, { useState, useEffect } from 'react';
import { 
  Gamepad2, Plus, Play, Settings2, Trash2, Edit3, 
  Sparkles, Check, Clock, ShieldCheck, Flame, ChevronRight, X
} from 'lucide-react';
import { GameProfile } from '../types/gameboost';
import { INITIAL_GAMES } from '../data/defaultGames';
import { GameSessionModal } from './GameSessionModal';
import { sound } from '../utils/sound';

export const GamesScreen: React.FC = () => {
  const [games, setGames] = useState<GameProfile[]>(() => {
    try {
      const saved = localStorage.getItem('gameboost_games_library');
      return saved ? JSON.parse(saved) : INITIAL_GAMES;
    } catch {
      return INITIAL_GAMES;
    }
  });

  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');
  const [activeSessionGame, setActiveSessionGame] = useState<GameProfile | null>(null);
  
  // Add / Edit Modal state
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingGame, setEditingGame] = useState<GameProfile | null>(null);
  
  // Editor form fields
  const [formTitle, setFormTitle] = useState('');
  const [formIcon, setFormIcon] = useState('🎮');
  const [formCategory, setFormCategory] = useState<GameProfile['category']>('FPS');
  const [formTargetFps, setFormTargetFps] = useState<GameProfile['targetFps']>(60);
  const [formGraphics, setFormGraphics] = useState<GameProfile['graphicsSetting']>('Médio');
  const [formNotes, setFormNotes] = useState('');
  const [formChecklistRaw, setFormChecklistRaw] = useState('');

  // Persist games changes
  const saveGames = (updated: GameProfile[]) => {
    setGames(updated);
    localStorage.setItem('gameboost_games_library', JSON.stringify(updated));
  };

  const handleOpenAdd = () => {
    sound.playClick();
    setEditingGame(null);
    setFormTitle('');
    setFormIcon('🎮');
    setFormCategory('FPS');
    setFormTargetFps(60);
    setFormGraphics('Médio');
    setFormNotes('');
    setFormChecklistRaw('Fechar apps recentes\nAtivar Não Perturbe\nConectar no Wi-Fi 5GHz');
    setIsEditorOpen(true);
  };

  const handleOpenEdit = (game: GameProfile, e: React.MouseEvent) => {
    e.stopPropagation();
    sound.playClick();
    setEditingGame(game);
    setFormTitle(game.title);
    setFormIcon(game.icon);
    setFormCategory(game.category);
    setFormTargetFps(game.targetFps);
    setFormGraphics(game.graphicsSetting);
    setFormNotes(game.notes || '');
    setFormChecklistRaw(game.checklist.join('\n'));
    setIsEditorOpen(true);
  };

  const handleDeleteGame = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    sound.playClick();
    if (confirm('Tem certeza que deseja remover este jogo da biblioteca?')) {
      const updated = games.filter(g => g.id !== id);
      saveGames(updated);
    }
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) return;

    const checklistItems = formChecklistRaw
      .split('\n')
      .map(line => line.trim())
      .filter(Boolean);

    if (editingGame) {
      // Update
      const updated = games.map(g => {
        if (g.id === editingGame.id) {
          return {
            ...g,
            title: formTitle.trim(),
            icon: formIcon.trim() || '🎮',
            category: formCategory,
            targetFps: formTargetFps,
            graphicsSetting: formGraphics,
            notes: formNotes.trim(),
            checklist: checklistItems.length > 0 ? checklistItems : ['Fechar apps em segundo plano'],
          };
        }
        return g;
      });
      saveGames(updated);
    } else {
      // Create
      const newGame: GameProfile = {
        id: `game_${Date.now()}`,
        title: formTitle.trim(),
        icon: formIcon.trim() || '🎮',
        category: formCategory,
        targetFps: formTargetFps,
        graphicsSetting: formGraphics,
        notes: formNotes.trim(),
        checklist: checklistItems.length > 0 ? checklistItems : ['Fechar apps em segundo plano'],
        playTimeMinutes: 0,
        lastPlayed: 'Novo',
      };
      saveGames([newGame, ...games]);
    }

    sound.playComplete();
    setIsEditorOpen(false);
  };

  const handleLaunchSession = (game: GameProfile) => {
    sound.playClick();
    setActiveSessionGame(game);
  };

  const handleSessionDone = (addedMinutes: number) => {
    if (!activeSessionGame) return;
    const updated = games.map(g => {
      if (g.id === activeSessionGame.id) {
        return {
          ...g,
          playTimeMinutes: (g.playTimeMinutes || 0) + addedMinutes,
          lastPlayed: 'Agora mesmo',
        };
      }
      return g;
    });
    saveGames(updated);
    setActiveSessionGame(null);
  };

  const categories = ['Todos', 'Battle Royale', 'FPS', 'MOBA', 'RPG', 'Corrida'];

  const filteredGames = games.filter(g => {
    if (selectedCategory === 'Todos') return true;
    return g.category === selectedCategory;
  });

  return (
    <div className="space-y-5 pb-6">
      {/* Top Header & Add Button */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-gamer font-bold text-white flex items-center gap-2">
            <span>Biblioteca de Jogos</span>
            <span className="text-xs bg-slate-800 text-cyan-400 px-2 py-0.5 rounded-full font-sans font-semibold">
              {games.length}
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Perfis de otimização e metas de taxa de quadros
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="py-2 px-3.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 text-xs font-semibold flex items-center gap-1.5 transition"
        >
          <Plus className="w-4 h-4" />
          <span>Adicionar</span>
        </button>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {categories.map(cat => {
          const isSelected = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => {
                sound.playClick();
                setSelectedCategory(cat);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-cyan-500 text-black font-bold shadow-[0_0_12px_rgba(0,245,212,0.4)]'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Games List */}
      <div className="space-y-3">
        {filteredGames.length === 0 ? (
          <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800">
            <Gamepad2 className="w-10 h-10 text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-300">Nenhum jogo nesta categoria</p>
            <p className="text-xs text-slate-500 mt-1">Toque em Adicionar para cadastrar seus jogos favoritos.</p>
          </div>
        ) : (
          filteredGames.map((game) => (
            <div
              key={game.id}
              className="p-4 rounded-2xl bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-slate-900/90 border border-slate-800 hover:border-slate-700 shadow-lg transition-all"
            >
              <div className="flex items-start justify-between">
                {/* Game Title & Category */}
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700/80 flex items-center justify-center text-2xl shadow-inner">
                    {game.icon}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white font-gamer">
                      {game.title}
                    </h3>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                      <span className="text-purple-400 font-medium">{game.category}</span>
                      <span>•</span>
                      <span>{game.lastPlayed || 'Recente'}</span>
                    </div>
                  </div>
                </div>

                {/* Edit & Delete Actions */}
                <div className="flex items-center gap-1">
                  <button
                    onClick={(e) => handleOpenEdit(game, e)}
                    title="Editar perfil"
                    className="p-1.5 text-slate-500 hover:text-cyan-400 rounded-lg hover:bg-slate-800 transition"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={(e) => handleDeleteGame(game.id, e)}
                    title="Remover"
                    className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Badges Profile Row */}
              <div className="flex items-center gap-2 mt-3 pt-3 border-t border-slate-800/80">
                <span className="px-2 py-0.5 rounded-lg bg-cyan-500/10 text-cyan-400 text-[11px] font-bold font-gamer border border-cyan-500/20">
                  🎯 Meta: {game.targetFps} FPS
                </span>
                <span className="px-2 py-0.5 rounded-lg bg-slate-800 text-slate-300 text-[11px] font-medium border border-slate-700/50">
                  Gráficos: {game.graphicsSetting}
                </span>
                {game.playTimeMinutes !== undefined && game.playTimeMinutes > 0 && (
                  <span className="text-[11px] text-slate-500 flex items-center gap-1 ml-auto">
                    <Clock className="w-3 h-3" />
                    {Math.round(game.playTimeMinutes / 60)}h {game.playTimeMinutes % 60}m
                  </span>
                )}
              </div>

              {/* Checklist items peek */}
              <div className="mt-2.5 text-[11px] text-slate-400">
                <span className="font-medium text-slate-300">Checklist ({game.checklist.length} passos): </span>
                <span className="italic">{game.checklist.slice(0, 2).join(', ')}...</span>
              </div>

              {/* Action Button: Preparar e Jogar */}
              <button
                onClick={() => handleLaunchSession(game)}
                className="mt-3.5 w-full py-2.5 px-4 rounded-xl font-gamer text-xs font-bold tracking-wider bg-gradient-to-r from-emerald-500/90 to-teal-500/90 hover:from-emerald-500 hover:to-teal-500 text-black flex items-center justify-center gap-2 transition shadow-md active:scale-98"
              >
                <Play className="w-3.5 h-3.5 fill-black" />
                <span>PREPARAR E JOGAR</span>
              </button>
            </div>
          ))
        )}
      </div>

      {/* Active Game Session HUD Modal */}
      {activeSessionGame && (
        <GameSessionModal
          game={activeSessionGame}
          onClose={() => setActiveSessionGame(null)}
          onSessionComplete={handleSessionDone}
        />
      )}

      {/* Add / Edit Game Modal */}
      {isEditorOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-[#0b101e] border border-slate-800 rounded-3xl p-5 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-gamer font-bold text-white">
                {editingGame ? 'Editar Perfil do Jogo' : 'Cadastrar Novo Jogo'}
              </h3>
              <button
                onClick={() => setIsEditorOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="overflow-y-auto no-scrollbar py-4 space-y-4 flex-1">
              {/* Title & Emoji */}
              <div className="grid grid-cols-4 gap-2">
                <div className="col-span-3">
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Nome do Jogo
                  </label>
                  <input
                    type="text"
                    required
                    value={formTitle}
                    onChange={e => setFormTitle(e.target.value)}
                    placeholder="Ex: Free Fire, COD..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Ícone
                  </label>
                  <input
                    type="text"
                    value={formIcon}
                    onChange={e => setFormIcon(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-center text-sm focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* Category */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Categoria
                </label>
                <select
                  value={formCategory}
                  onChange={e => setFormCategory(e.target.value as GameProfile['category'])}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400"
                >
                  <option value="Battle Royale">Battle Royale</option>
                  <option value="FPS">FPS / Tiro</option>
                  <option value="MOBA">MOBA</option>
                  <option value="RPG">RPG / Aventura</option>
                  <option value="Corrida">Corrida</option>
                  <option value="Outro">Outro</option>
                </select>
              </div>

              {/* Target FPS & Graphics Setting */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Taxa Alvo (FPS)
                  </label>
                  <select
                    value={formTargetFps}
                    onChange={e => setFormTargetFps(Number(e.target.value) as GameProfile['targetFps'])}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400"
                  >
                    <option value={30}>30 FPS (Bateria)</option>
                    <option value={60}>60 FPS (Padrão)</option>
                    <option value={90}>90 FPS (Fluidez)</option>
                    <option value={120}>120 FPS (Ultra)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Gráficos Recomendados
                  </label>
                  <select
                    value={formGraphics}
                    onChange={e => setFormGraphics(e.target.value as GameProfile['graphicsSetting'])}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400"
                  >
                    <option value="Baixo">Baixo / Suave (Max FPS)</option>
                    <option value="Médio">Médio (Equilibrado)</option>
                    <option value="Alto">Alto (Visual)</option>
                    <option value="Ultra">Ultra (Aparelhos Top)</option>
                  </select>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Notas de Otimização (Opcional)
                </label>
                <input
                  type="text"
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  placeholder="Ex: Desative sombra e ative Alto FPS dentro do jogo"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400"
                />
              </div>

              {/* Checklist */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Checklist Pré-Jogo (Um item por linha)
                </label>
                <textarea
                  rows={4}
                  value={formChecklistRaw}
                  onChange={e => setFormChecklistRaw(e.target.value)}
                  placeholder="Fechar apps recentes&#10;Ativar Não Perturbe&#10;Wi-Fi 5GHz"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl font-gamer text-xs font-bold tracking-wider bg-cyan-400 hover:bg-cyan-300 text-black shadow-lg"
                >
                  {editingGame ? 'SALVAR ALTERAÇÕES' : 'SALVAR NOVO JOGO'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
