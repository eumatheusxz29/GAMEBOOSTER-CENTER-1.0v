import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function crc32(buf) {
  let table = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      if (c & 1) c = 0xedb88320 ^ (c >>> 1);
      else c = c >>> 1;
    }
    table[n] = c;
  }
  let c = 0 ^ -1;
  for (let i = 0; i < buf.length; i++) {
    c = table[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ -1) >>> 0;
}

function createChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.alloc(4);
  const crc = crc32(Buffer.concat([typeBuf, data]));
  crcBuf.writeUInt32BE(crc, 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function generatePNG(size, isMaskable = false) {
  const width = size;
  const height = size;
  const rawData = Buffer.alloc((width * 4 + 1) * height);

  const cx = width / 2;
  const cy = height / 2;
  const radius = width * 0.45;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * (width * 4 + 1);
    rawData[rowOffset] = 0; // Filter type: None

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Background
      let r = 11, g = 15, b = 25; // Dark slate #0b0f19

      if (!isMaskable) {
        // Rounded squircle / circular border glow
        const borderDist = Math.abs(dist - radius * 0.92);
        if (borderDist < radius * 0.08) {
          // Neon cyan/emerald ring
          const t = (x + y) / (width + height);
          r = Math.floor(0 * (1 - t) + 16 * t);
          g = Math.floor(245 * (1 - t) + 185 * t);
          b = Math.floor(212 * (1 - t) + 129 * t);
        }
      } else {
        // Maskable has safe zone and solid gradient background
        const t = (x + y) / (width + height);
        r = Math.floor(10 + t * 15);
        g = Math.floor(16 + t * 25);
        b = Math.floor(30 + t * 40);
      }

      // Draw stylized lightning / boost chevron in center
      // Center icon coordinates normalized -1 to 1
      const nx = (x - cx) / (radius * 0.7);
      const ny = (y - cy) / (radius * 0.7);

      // Lightning bolt shape
      const inBolt = (
        (nx > -0.3 && nx < 0.25 && ny > -0.8 && ny < -0.1 && (ny - 2 * nx) > -0.9 && (ny - 2 * nx) < 0.2) ||
        (nx > -0.4 && nx < 0.35 && ny >= -0.2 && ny <= 0.8 && (ny - 2.5 * nx) > -0.6 && (ny - 2.5 * nx) < 0.8)
      );

      // Rocket / Gamepad accents
      const inPadLeft = Math.sqrt((nx + 0.35) ** 2 + (ny - 0.2) ** 2) < 0.28;
      const inPadRight = Math.sqrt((nx - 0.35) ** 2 + (ny - 0.2) ** 2) < 0.28;
      const inPadCross = (nx > -0.45 && nx < 0.45 && ny > 0.05 && ny < 0.35);

      if (inBolt) {
        // Bright electric cyan / emerald
        r = 0;
        g = 255;
        b = 200;
      } else if (inPadLeft || inPadRight || inPadCross) {
        // Cyber purple & deep cyan accents
        r = 139;
        g = 92;
        b = 246;
      }

      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = 255; // Alpha
    }
  }

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type: RGBA
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  const ihdrChunk = createChunk('IHDR', ihdr);
  const compressedData = zlib.deflateSync(rawData);
  const idatChunk = createChunk('IDAT', compressedData);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), generatePNG(192));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), generatePNG(512));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), generatePNG(512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), generatePNG(180));
console.log('Icons generated successfully.');
