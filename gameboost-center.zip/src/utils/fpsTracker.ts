// Real-time FPS Tracker using requestAnimationFrame

export interface FpsDataPoint {
  second: number;
  time: string;
  fps: number;
  frametime: number;
}

class FPSTracker {
  private lastTime: number = performance.now();
  private frames: number = 0;
  private currentFps: number = 60;
  private currentFrametime: number = 16.6;
  private frameTimesList: number[] = [];
  private history: FpsDataPoint[] = [];
  private maxHistorySeconds: number = 60;
  private animationFrameId: number | null = null;
  private isRunning: boolean = false;
  private listeners: Set<(fps: number, frametime: number, history: FpsDataPoint[]) => void> = new Set();
  private secondCounter: number = 0;
  private onePercentLow: number = 60;
  private jitter: number = 0.5;

  public start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastTime = performance.now();
    this.frames = 0;

    // Initialize 60 seconds with reasonable baseline so chart looks ready immediately
    if (this.history.length === 0) {
      const now = new Date();
      for (let i = 60; i >= 1; i--) {
        const d = new Date(now.getTime() - i * 1000);
        const timeStr = `${d.getMinutes().toString().padStart(2, '0')}:${d.getSeconds().toString().padStart(2, '0')}`;
        this.history.push({
          second: 60 - i,
          time: timeStr,
          fps: 60,
          frametime: 16.6,
        });
      }
    }

    this.tick = this.tick.bind(this);
    this.animationFrameId = requestAnimationFrame(this.tick);
  }

  public stop() {
    this.isRunning = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  private tick(now: number) {
    if (!this.isRunning) return;

    this.frames++;
    const delta = now - this.lastTime;
    const singleFrameTime = delta / (this.frames || 1);
    this.frameTimesList.push(singleFrameTime);

    if (delta >= 1000) {
      const measuredFps = Math.round((this.frames * 1000) / delta);
      this.currentFps = Math.min(144, Math.max(1, measuredFps));
      this.currentFrametime = Math.round((1000 / this.currentFps) * 10) / 10;

      // Calculate 1% low and jitter
      if (this.frameTimesList.length > 5) {
        const sorted = [...this.frameTimesList].sort((a, b) => b - a); // highest frame times = worst drops
        const idx = Math.floor(sorted.length * 0.01);
        const worstFrame = sorted[idx] || sorted[0];
        this.onePercentLow = Math.max(1, Math.round(1000 / worstFrame));

        // Jitter (variance from ideal 16.6ms)
        const avg = this.frameTimesList.reduce((acc, v) => acc + v, 0) / this.frameTimesList.length;
        const diffs = this.frameTimesList.map(v => Math.abs(v - avg));
        this.jitter = Math.round((diffs.reduce((acc, v) => acc + v, 0) / diffs.length) * 10) / 10;
      }

      const date = new Date();
      const timeStr = `${date.getMinutes().toString().padStart(2, '0')}:${date.getSeconds().toString().padStart(2, '0')}`;

      this.secondCounter++;
      this.history.push({
        second: this.secondCounter,
        time: timeStr,
        fps: this.currentFps,
        frametime: this.currentFrametime,
      });

      if (this.history.length > this.maxHistorySeconds) {
        this.history.shift();
      }

      this.frames = 0;
      this.lastTime = now;
      this.frameTimesList = [];

      this.notify();
    }

    this.animationFrameId = requestAnimationFrame(this.tick);
  }

  private notify() {
    for (const listener of this.listeners) {
      listener(this.currentFps, this.currentFrametime, [...this.history]);
    }
  }

  public subscribe(cb: (fps: number, frametime: number, history: FpsDataPoint[]) => void) {
    this.listeners.add(cb);
    // Send immediate current state
    cb(this.currentFps, this.currentFrametime, [...this.history]);
    return () => {
      this.listeners.delete(cb);
    };
  }

  public getStats() {
    return {
      fps: this.currentFps,
      frametime: this.currentFrametime,
      onePercentLow: this.onePercentLow,
      jitter: this.jitter,
      history: [...this.history],
    };
  }
}

export const fpsTracker = new FPSTracker();
// Start tracking right away
if (typeof window !== 'undefined') {
  fpsTracker.start();
}
