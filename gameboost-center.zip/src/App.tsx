/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNav, TabType } from './components/BottomNav';
import { HomeDashboard } from './components/HomeDashboard';
import { BoostScreen } from './components/BoostScreen';
import { GamesScreen } from './components/GamesScreen';
import { MonitorScreen } from './components/MonitorScreen';
import { TipsScreen } from './components/TipsScreen';
import { TransparencyModal } from './components/TransparencyModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { HardwareStats } from './types/gameboost';
import { getHardwareStats } from './utils/hardware';
import { fpsTracker } from './utils/fpsTracker';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [stats, setStats] = useState<HardwareStats | null>(null);
  const [currentFps, setCurrentFps] = useState<number>(60);
  const [gameModeActive, setGameModeActive] = useState<boolean>(() => {
    try {
      return localStorage.getItem('gameboost_mode_active') === 'true';
    } catch {
      return false;
    }
  });
  const [isTransparencyModalOpen, setIsTransparencyModalOpen] = useState<boolean>(false);

  // Load real hardware stats
  const refreshHardware = async () => {
    try {
      const data = await getHardwareStats();
      setStats(data);
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    refreshHardware();
    // Subscribe to FPS
    const unsubscribe = fpsTracker.subscribe((fps) => {
      setCurrentFps(fps);
    });
    return unsubscribe;
  }, []);

  const handleToggleGameMode = () => {
    setGameModeActive(prev => {
      const next = !prev;
      localStorage.setItem('gameboost_mode_active', String(next));
      return next;
    });
  };

  return (
    <div className={`min-h-screen bg-[#060911] text-slate-100 flex flex-col cyber-grid-bg relative selection:bg-emerald-500 selection:text-black ${
      gameModeActive ? 'ring-1 ring-emerald-500/30' : ''
    }`}>
      {/* Offline Status Bar */}
      <OfflineIndicator />

      {/* App Header */}
      <Header
        gameModeActive={gameModeActive}
        onOpenTransparencyModal={() => setIsTransparencyModalOpen(true)}
      />

      {/* Main Content Area (Mobile-First Container) */}
      <main className="flex-1 max-w-md w-full mx-auto px-4 pt-4 pb-24">
        {currentTab === 'home' && (
          <HomeDashboard
            stats={stats}
            currentFps={currentFps}
            gameModeActive={gameModeActive}
            onToggleGameMode={handleToggleGameMode}
            onGoToBoost={() => setCurrentTab('boost')}
            onGoToMonitor={() => setCurrentTab('monitor')}
            onRefreshHardware={refreshHardware}
          />
        )}

        {currentTab === 'boost' && (
          <BoostScreen />
        )}

        {currentTab === 'games' && (
          <GamesScreen />
        )}

        {currentTab === 'monitor' && (
          <MonitorScreen stats={stats} />
        )}

        {currentTab === 'tips' && (
          <TipsScreen />
        )}
      </main>

      {/* Transparency / Settings Notice Modal */}
      {isTransparencyModalOpen && (
        <TransparencyModal
          onClose={() => setIsTransparencyModalOpen(false)}
          storageUsedMB={stats?.storageUsedMB ?? null}
          storageQuotaMB={stats?.storageQuotaMB ?? null}
        />
      )}

      {/* Bottom 5-Tab Navigation */}
      <BottomNav
        currentTab={currentTab}
        onChangeTab={setCurrentTab}
      />
    </div>
  );
}
