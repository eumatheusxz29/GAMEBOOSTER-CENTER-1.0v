export interface HardwareStats {
  ramGB: number | null; // navigator.deviceMemory
  cpuCores: number;     // navigator.hardwareConcurrency
  screenRefreshRate: number; // estimated Hz (60, 90, 120, etc.)
  screenResolution: string;  // e.g. "1080 x 2400"
  devicePixelRatio: number;
  batteryLevel: number | null; // 0 to 100
  isCharging: boolean | null;
  connectionType: string;      // "4g", "wifi", etc.
  downlinkMbps: number | null;
  rttMs: number | null;
  gpuRenderer: string;
  storageUsedMB: number | null;
  storageQuotaMB: number | null;
  browserHeapMB: number | null; // performance.memory (Chrome)
}

export interface GameProfile {
  id: string;
  title: string;
  category: 'Battle Royale' | 'FPS' | 'MOBA' | 'Corrida' | 'RPG' | 'Outro';
  icon: string; // emoji or icon name
  targetFps: 30 | 60 | 90 | 120;
  graphicsSetting: 'Baixo' | 'Médio' | 'Alto' | 'Ultra';
  notes?: string;
  checklist: string[];
  lastPlayed?: string;
  playTimeMinutes?: number;
}

export interface OptimizationStepResult {
  id: string;
  title: string;
  description: string;
  realActionExecuted: string;
  status: 'pending' | 'running' | 'success' | 'skipped';
  details?: string;
}

export interface BenchmarkResult {
  avgFps: number;
  minFps: number;
  maxFps: number;
  onePercentLow: number;
  jitterMs: number;
  score: number;
  rating: 'Excelente' | 'Bom' | 'Regular' | 'Ruim';
  testedAt: string;
}
