import React from 'react';
import { Home, Zap, Gamepad2, Activity, Lightbulb } from 'lucide-react';
import { sound } from '../utils/sound';

export type TabType = 'home' | 'boost' | 'games' | 'monitor' | 'tips';

interface BottomNavProps {
  currentTab: TabType;
  onChangeTab: (tab: TabType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onChangeTab }) => {
  const tabs: { id: TabType; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', label: 'Início', icon: Home },
    { id: 'boost', label: 'Boost', icon: Zap },
    { id: 'games', label: 'Jogos', icon: Gamepad2 },
    { id: 'monitor', label: 'Monitor', icon: Activity },
    { id: 'tips', label: 'Dicas', icon: Lightbulb },
  ];

  const handleSelect = (tab: TabType) => {
    if (tab !== currentTab) {
      sound.playClick();
      onChangeTab(tab);
    }
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#070b14]/95 backdrop-blur-lg border-t border-slate-800/80 px-2 py-1 pb-safe">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => handleSelect(tab.id)}
              className={`relative flex flex-col items-center py-2 px-3 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'text-cyan-400 font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {/* Highlight active dot / glow */}
              {isActive && (
                <span className="absolute -top-1 w-8 h-1 rounded-full bg-gradient-to-r from-emerald-400 via-cyan-400 to-purple-500 shadow-[0_0_12px_rgba(0,245,212,0.8)]" />
              )}

              <div className={`transition-transform duration-200 ${isActive ? 'scale-110' : 'scale-100'}`}>
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.4]' : 'stroke-[1.8]'}`} />
              </div>

              <span className={`text-[11px] mt-1 tracking-tight ${isActive ? 'text-white font-semibold' : 'text-slate-400'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
