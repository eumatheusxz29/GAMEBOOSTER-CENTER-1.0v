export interface TipItem {
  id: string;
  category: 'Sistema' | 'Bateria' | 'Rede' | 'Armazenamento' | 'Temperatura' | 'Gráficos';
  title: string;
  badge: string;
  summary: string;
  content: string[];
  osSteps?: {
    platform: string;
    steps: string[];
  }[];
}

export const TIPS_DATA: TipItem[] = [
  {
    id: 'sys-bg-apps',
    category: 'Sistema',
    title: 'Fechar apps recentes antes de entrar na partida',
    badge: 'Essencial',
    summary: 'Aplicativos como Instagram, TikTok e navegadores retêm memória RAM e realizam tarefas em background.',
    content: [
      'Nenhum site web consegue forçar o encerramento de apps de terceiros no celular.',
      'Abra a tela de multitarefas do seu celular (deslize de baixo para cima ou botão de quadrados) e toque em "Fechar Tudo" ou "Limpar Tudo".',
      'Isso devolve a memória física ao Android para o jogo usar sem engasgos (micro-stutters).',
    ],
    osSteps: [
      {
        platform: 'Android',
        steps: ['Deslize a partir do rodapé e segure', 'Toque em "Limpar tudo" ou deslize os apps para cima', 'Se tiver apps de mensagem fixados com cadeado, desafixe-os antes'],
      },
      {
        platform: 'iOS (iPhone)',
        steps: ['Deslize para cima a partir da barra inferior', 'Deslize para cima cada app aberto para encerrar'],
      },
    ],
  },
  {
    id: 'sys-game-mode',
    category: 'Sistema',
    title: 'Ativar o Game Turbo / Game Space nativo do aparelho',
    badge: 'Hardware',
    summary: 'Aparelhos Xiaomi, Samsung, Motorola e Asus possuem um Game Booster de fábrica embutido no sistema.',
    content: [
      'Aplicações do sistema conseguem elevar o clock da CPU e GPU, algo que apps de terceiros ou web não têm permissão de fazer.',
      'No Samsung: ative o "Game Booster" / "Game Plugins" e ative a taxa de amostragem de toque no máximo.',
      'No Xiaomi / POCO: adicione o jogo ao "Game Turbo" para habilitar prioridade de rede e desativar gestos acidentais.',
      'No Motorola: utilize o aplicativo "Moto Gametime" para silenciar ligações e gravar replays com baixo consumo.',
    ],
  },
  {
    id: 'sys-dnd',
    category: 'Sistema',
    title: 'Modo Não Perturbe (DND) e Bloqueio de Notificações',
    badge: 'Foco Total',
    summary: 'Notificações popup fazem a GPU renderizar sobreposições no meio da ação, causando quedas bruscas de FPS.',
    content: [
      'Uma mensagem recebida enquanto você mira força o compositor do Android a desenhar o banner, causando queda de quadros no jogo.',
      'Ative o "Não Perturbe" na cortina de atalhos rápidos do celular antes de iniciar.',
    ],
  },
  {
    id: 'bat-saver-off',
    category: 'Bateria',
    title: 'Desligar a Economia de Bateria antes de jogar',
    badge: 'Impacto Alto',
    summary: 'O modo economia reduz a velocidade máxima do processador em até 40% e limita a taxa de quadros.',
    content: [
      'Ao ativar a economia de bateria, o celular reduz o clock da CPU para economizar miliamperes.',
      'Em jogos rápidos, isso causa travamentos e congelamentos na tela.',
      'Sempre desative o modo economia e jogue preferencialmente com mais de 30% de carga.',
    ],
    osSteps: [
      {
        platform: 'Android',
        steps: ['Abra a barra de notificações', 'Localize o ícone "Economia de energia"', 'Desative antes de iniciar a sessão'],
      },
    ],
  },
  {
    id: 'bat-bypass-charging',
    category: 'Bateria',
    title: 'Jogar plugado no carregador: cuidados com o calor',
    badge: 'Técnico',
    summary: 'Carregar enquanto joga gera calor duplo (bateria recebendo energia + GPU trabalhando).',
    content: [
      'Se o seu aparelho tem "Bypass Charging" ou "Pausa no carregamento USB" (comum em Samsung, Asus ROG, Black Shark), ATIVE-O! Ele alimenta os circuitos diretamente sem esquentar a bateria.',
      'Se o seu celular não tem essa função, evite jogar partidas pesadas com carregador rápido ligado se a temperatura ambiente estiver alta.',
    ],
  },
  {
    id: 'net-wifi-5ghz',
    category: 'Rede',
    title: 'Prefira Wi-Fi de 5 GHz ao invés de 2.4 GHz',
    badge: 'Menor Ping',
    summary: 'Redes de 2.4 GHz sofrem forte interferência de Bluetooth, micro-ondas e vizinhos, gerando picos de ping.',
    content: [
      'A frequência de 5 GHz oferece largura de canal muito mais limpa e latência (ping) estável, sem oscilações bruscas.',
      'Fique no mesmo cômodo ou a poucas paredes de distância do roteador.',
      'Se o seu roteador une as redes num nome só (Smart Connect), prefira separar em redes "MeuWifi" e "MeuWifi_5G".',
    ],
  },
  {
    id: 'net-mobile-data',
    category: 'Rede',
    title: 'Quando o 4G/5G supera o Wi-Fi residencial',
    badge: 'Dica Pro',
    summary: 'Se outras pessoas na sua casa estão assistindo filmes em 4K ou fazendo downloads, o ping do Wi-Fi vai explodir.',
    content: [
      'O 4G/5G possui rota dedicada e não é afetado por downloads que ocorrem na rede da sua casa.',
      'Um jogo consome apenas entre 30 MB a 80 MB de dados por hora em média (muito pouco!).',
      'Faça um teste de ping no Monitor do app antes de começar ranqueadas.',
    ],
  },
  {
    id: 'sto-clear-junk',
    category: 'Armazenamento',
    title: 'Manter pelo menos 15% a 20% de espaço livre',
    badge: 'Armazenamento',
    summary: 'Memórias flash (UFS/eMMC) perdem drasticamente velocidade de leitura e escrita quando estão cheias.',
    content: [
      'Quando o armazenamento ultrapassa 85-90% de ocupação, o sistema Android tem dificuldade para gerenciar a memória virtual (swap/zRAM).',
      'Desinstale jogos que você não joga mais e faça backup de vídeos pesados no Google Fotos ou na nuvem.',
      'Apague dados temporários e downloads antigos pela ferramenta "Arquivos do Google" (Files by Google).',
    ],
  },
  {
    id: 'temp-thermal-throttle',
    category: 'Temperatura',
    title: 'Thermal Throttling: O maior vilão das quedas de FPS',
    badge: 'Superaquecimento',
    summary: 'Após 15 a 20 minutos de jogo, o processador esquenta e reduz sua velocidade sozinho para não queimar.',
    content: [
      'Sintoma comum: os primeiros 10 minutos de jogo rodam a 60 FPS lisos, depois cai para 35-40 FPS com travamentos.',
      'Remova a capinha protetora de silicone ou couro durante as jogatinas longas — elas agem como um isolante térmico que aprisiona o calor.',
      'Jogue em ambiente arejado ou com ventilador apontado.',
      'Considere coolers magnéticos para celular se joga competitivamente por mais de 1 hora seguida.',
    ],
  },
  {
    id: 'gfx-fps-over-graphics',
    category: 'Gráficos',
    title: 'Regra de Ouro: Taxa de Quadros Alta > Efeitos Gráficos',
    badge: 'Competitivo',
    summary: 'Sombras, reflexos na água e pós-processamento consom muito poder de GPU sem trazer vantagem competitiva.',
    content: [
      'Em jogos de tiro e ação, gráficos no nível "Suave" ou "Baixo" facilitam enxergar inimigos à distância e reduzem a fumaça de efeitos visuais.',
      'Coloque a qualidade gráfica no menor nível e coloque a "Taxa de Quadros" no nível máximo disponível (Alta/Ultra/60 FPS).',
      'Desative a opção "Anti-Aliasing" (suavização de serrilhado) e sombras dinâmicas para economizar até 35% de GPU.',
    ],
  },
];
