import React from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { WifiOff } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed top-14 left-4 right-4 z-50 max-w-md mx-auto flex items-center justify-between gap-2 rounded-xl bg-amber-500/95 text-black px-3.5 py-2 text-xs font-semibold shadow-lg backdrop-blur-sm animate-bounce">
      <div className="flex items-center gap-2">
        <WifiOff className="w-4 h-4 shrink-0" />
        <span>Modo Offline: Recursos e perfis salvos em cache continuam funcionando.</span>
      </div>
    </div>
  );
};
